/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        "carys-blue": "#2F7BFF",
      },
      boxShadow: {
        soft: "0 4px 14px rgba(0,0,0,0.08)",
      }
    },
  },
  plugins: [],
};