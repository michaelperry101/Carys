export const dynamic = "force-static";

export default function SubscribePage() {
  return (
    <div className="space-y-6 max-w-xl">
      <h1 className="text-2xl font-semibold">Subscribe</h1>
      <div className="rounded-2xl bg-white p-6 shadow-soft border space-y-4">
        <p className="text-neutral-700">Choose Pro via Stripe Buy Button:</p>
        <script async src="https://js.stripe.com/v3/buy-button.js"></script>
        <stripe-buy-button
          buy-button-id="buy_btn_1S3lNsE94w0NsCoprzjoxcg6"
          publishable-key="pk_test_51RxapUE94w0NsCopB4LcDrt3uBJkflD8U3tXiku7SQaAflFqDhjrt8YfGDCcawUt2kf3PQLytAA6l6JpfxFHjfCf00LGHY8nae"
        ></stripe-buy-button>
        <p className="text-xs text-neutral-500">
          Replace the IDs with your live keys before going live.
        </p>
      </div>
    </div>
  );
}