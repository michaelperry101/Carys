import NextAuth from "next-auth";
import { providers, authCallbacks } from "@/lib/authOptions";

const handler = NextAuth({
  providers,
  session: { strategy: "jwt" },
  callbacks: authCallbacks,
});

export { handler as GET, handler as POST };