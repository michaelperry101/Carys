export const dynamic = "force-static";

export default function TermsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Terms of Service</h1>
      <div className="rounded-2xl bg-white p-6 shadow-soft border space-y-3 text-neutral-700">
        <p>Sample terms. Replace with your own legal terms before launch.</p>
        <ul className="list-disc ml-6">
          <li>Use of Carys is subject to fair use.</li>
          <li>No illegal content or activities.</li>
          <li>Subscriptions are billed monthly; cancel anytime.</li>
        </ul>
      </div>
    </div>
  );
}