export const dynamic = "force-static";

export default function NotFound() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Page not found</h1>
      <p>We couldn’t find that page. Try the sidebar to navigate.</p>
    </div>
  );
}