export const dynamic = "force-static";

export default function HomePage() {
  return (
    <div className="space-y-8">
      <section className="rounded-2xl bg-white p-8 shadow-soft border">
        <h1 className="text-3xl font-bold mb-3">Meet Carys</h1>
        <p className="text-neutral-700 max-w-2xl">
          Built on a Transformer architecture with encoder–decoder and self‑attention, Carys helps you
          research, write, code, and create — across 40+ languages. Almost identical to the ChatGPT
          experience you know, thoughtfully refined.
        </p>
        <div className="mt-6 flex gap-3">
          <a href="/chat" className="rounded-xl bg-carys-blue text-white px-5 py-2">Start Chatting</a>
          <a href="/subscribe" className="rounded-xl border px-5 py-2">Upgrade</a>
        </div>
      </section>

      <section className="grid md:grid-cols-3 gap-4">
        {[
          {title:"Turn words into videos",desc:"Generate visuals with integrated video tooling (Sora/Veo ready stubs)."},
          {title:"Ask complex questions",desc:"Deep research modes condense hours of searching."},
          {title:"Create images in seconds",desc:"Imagen and GPT‑4o image generation endpoints (stubs)."},
          {title:"Talk it out",desc:"Voice mode ready."},
          {title:"Custom chatbots",desc:"Create task‑specific assistants (Pro)."},
          {title:"Works everywhere",desc:"Web, mobile and desktop ready UI."},
        ].map((c)=>(
          <div key={c.title} className="rounded-2xl bg-white p-6 shadow-soft border">
            <div className="font-semibold mb-2">{c.title}</div>
            <div className="text-sm text-neutral-600">{c.desc}</div>
          </div>
        ))}
      </section>
    </div>
  );
}