"use client";
import { useState } from "react";

export default function SettingsForm() {
  const [model, setModel] = useState("gpt-4o-mini");
  const [language, setLanguage] = useState("English");
  const [memory, setMemory] = useState(true);
  const [webSearch, setWebSearch] = useState(true);
  const [voice, setVoice] = useState(false);
  const [theme, setTheme] = useState("light");

  return (
    <form className="space-y-6">
      <section className="rounded-2xl bg-white p-5 shadow-soft border">
        <h2 className="text-lg font-semibold mb-4">Model</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="flex items-center gap-3">
            <input type="radio" name="model" value="gpt-4o-mini" checked={model==="gpt-4o-mini"} onChange={()=>setModel("gpt-4o-mini")} />
            GPT-4o mini (free)
          </label>
          <label className="flex items-center gap-3">
            <input type="radio" name="model" value="gpt-4o" checked={model==="gpt-4o"} onChange={()=>setModel("gpt-4o")} />
            GPT-4o
          </label>
          <label className="flex items-center gap-3">
            <input type="radio" name="model" value="o3" checked={model==="o3"} onChange={()=>setModel("o3")} />
            o3
          </label>
          <label className="flex items-center gap-3">
            <input type="radio" name="model" value="o4-mini" checked={model==="o4-mini"} onChange={()=>setModel("o4-mini")} />
            o4-mini
          </label>
          <label className="flex items-center gap-3">
            <input type="radio" name="model" value="gemini-2.5-flash" checked={model==="gemini-2.5-flash"} onChange={()=>setModel("gemini-2.5-flash")} />
            Gemini 2.5 Flash (free)
          </label>
          <label className="flex items-center gap-3">
            <input type="radio" name="model" value="gemini-2.5-pro" checked={model==="gemini-2.5-pro"} onChange={()=>setModel("gemini-2.5-pro")} />
            Gemini 2.5 Pro
          </label>
        </div>
      </section>

      <section className="rounded-2xl bg-white p-5 shadow-soft border">
        <h2 className="text-lg font-semibold mb-4">Preferences</h2>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm mb-2">Language</label>
            <select className="w-full rounded-lg border px-3 py-2" value={language} onChange={e=>setLanguage(e.target.value)}>
              <option>English</option>
              <option>Spanish</option>
              <option>French</option>
              <option>German</option>
              <option>Italian</option>
              <option>Portuguese</option>
              <option>Chinese</option>
              <option>Japanese</option>
              <option>Korean</option>
            </select>
          </div>
          <div className="flex items-center gap-3">
            <input id="memory" type="checkbox" checked={memory} onChange={(e)=>setMemory(e.target.checked)} />
            <label htmlFor="memory">Enable Memory</label>
          </div>
          <div className="flex items-center gap-3">
            <input id="websearch" type="checkbox" checked={webSearch} onChange={(e)=>setWebSearch(e.target.checked)} />
            <label htmlFor="websearch">Real-time Web Search</label>
          </div>
          <div className="flex items-center gap-3">
            <input id="voice" type="checkbox" checked={voice} onChange={(e)=>setVoice(e.target.checked)} />
            <label htmlFor="voice">Voice Mode</label>
          </div>
          <div>
            <label className="block text-sm mb-2">Theme</label>
            <select className="w-full rounded-lg border px-3 py-2" value={theme} onChange={e=>setTheme(e.target.value)}>
              <option value="light">Light</option>
              <option value="dark">Dark</option>
              <option value="system">System</option>
            </select>
          </div>
        </div>
      </section>

      <section className="rounded-2xl bg-white p-5 shadow-soft border">
        <h2 className="text-lg font-semibold mb-4">Account & Billing</h2>
        <p className="text-sm text-neutral-600">Manage your subscription and payment preferences on the Subscribe page.</p>
      </section>

      <button type="button" className="rounded-xl bg-carys-blue text-white px-4 py-2">
        Save Settings
      </button>
    </form>
  );
}