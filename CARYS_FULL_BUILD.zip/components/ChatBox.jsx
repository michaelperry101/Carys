"use client";
import { useEffect, useRef, useState } from "react";

export default function ChatBox() {
  const [messages, setMessages] = useState([
    { id: 1, role: "assistant", content: "Hi! I’m Carys. How can I help today?" }
  ]);
  const [input, setInput] = useState("");
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const send = () => {
    if (!input.trim()) return;
    setMessages((m) => [...m, { id: Date.now(), role: "user", content: input }]);
    // Fake assistant response for now
    setTimeout(() => {
      setMessages((m) => [...m, { id: Date.now()+1, role: "assistant", content: "Got it! (demo reply)" }]);
    }, 400);
    setInput("");
  };

  return (
    <div className="rounded-2xl border bg-white shadow-soft h-[70vh] flex flex-col">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m) => (
          <div key={m.id} className={m.role === "user" ? "text-right" : "text-left"}>
            <div className={[
              "inline-block rounded-2xl px-4 py-2",
              m.role === "user" ? "bg-blue-600 text-white" : "bg-neutral-100"
            ].join(" ")}>
              {m.content}
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>
      <div className="border-t p-3 flex gap-2">
        <input
          className="flex-1 rounded-xl border px-3 py-2"
          placeholder="Message Carys..."
          value={input}
          onChange={(e)=>setInput(e.target.value)}
          onKeyDown={(e)=>{ if(e.key==='Enter') send(); }}
        />
        <button onClick={send} className="rounded-xl bg-carys-blue text-white px-4 py-2">Send</button>
      </div>
    </div>
  );
}