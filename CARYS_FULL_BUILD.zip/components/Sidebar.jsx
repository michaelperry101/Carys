"use client";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useState } from "react";

const nav = [
  { href: "/", label: "Home", icon: "/icons/home.png" },
  { href: "/chat", label: "Start Chatting", icon: "/icons/chat.png" },
  { href: "/settings", label: "Settings", icon: "/icons/settings.png" },
  { href: "/reviews", label: "Reviews", icon: "/icons/reviews.png" },
  { href: "/subscribe", label: "Subscribe", icon: "/icons/subscribe.png" },
  { href: "/about", label: "About", icon: "/icons/about.png" },
  { href: "/terms", label: "Terms", icon: "/icons/terms.png" },
  { href: "/privacy", label: "Privacy", icon: "/icons/privacy.png" },
  { href: "/login", label: "Login / Create Account", icon: "/icons/login.png" },
];

export default function Sidebar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <>
      {/* Mobile toggle */}
      <button
        className="md:hidden fixed z-50 left-4 top-4 rounded-xl border px-3 py-2 bg-white shadow-sm"
        onClick={() => setOpen((v) => !v)}
        aria-label="Open menu"
      >
        Menu
      </button>

      {/* Overlay for mobile */}
      {open && (
        <div
          className="fixed inset-0 z-40 bg-black/30 md:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      <aside
        className={[
          "fixed z-50 md:z-0 md:static md:translate-x-0",
          "left-0 top-0 h-full w-72 border-r bg-white",
          "transition-transform duration-200",
          open ? "translate-x-0" : "-translate-x-full md:translate-x-0",
          "flex flex-col",
        ].join(" ")}
      >
        {/* Brand */}
        <div className="flex items-center gap-3 px-4 py-4 border-b">
          <Image src="/logo.png" alt="Carys" width={32} height={32} priority />
          <span className="text-xl font-semibold">Carys</span>
        </div>

        {/* Scrollable nav */}
        <nav className="flex-1 overflow-y-auto px-2 py-3">
          <ul className="space-y-1">
            {nav.map((item) => {
              const active =
                item.href === "/"
                  ? pathname === "/"
                  : pathname?.startsWith(item.href);
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className={[
                      "flex items-center gap-3 rounded-lg px-3 py-2 text-sm",
                      active
                        ? "bg-blue-50 text-blue-700"
                        : "hover:bg-neutral-100",
                    ].join(" ")}
                    onClick={() => setOpen(false)}
                  >
                    <Image src={item.icon} alt="" width={18} height={18} />
                    <span>{item.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>

          {/* CTA button */}
          <div className="mt-6 px-1">
            <Link
              href="/chat"
              className="inline-flex w-full items-center justify-center rounded-xl px-4 py-2 text-sm font-medium bg-blue-500/10 text-blue-700 hover:bg-blue-500/15 border border-blue-200"
              onClick={() => setOpen(false)}
            >
              Start Chatting
            </Link>
          </div>
        </nav>

        {/* Footer */}
        <div className="border-t p-3 text-xs text-neutral-500">
          © {new Date().getFullYear()} Carys
        </div>
      </aside>
    </>
  );
}