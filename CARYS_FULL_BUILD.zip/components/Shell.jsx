import Sidebar from "@/components/Sidebar";

export default function Shell({ children }) {
  return (
    <div className="min-h-screen flex">
      <Sidebar />
      <main className="flex-1 md:ml-0 md:pl-72 p-4 md:p-6">
        <div className="container-g">{children}</div>
      </main>
    </div>
  );
}