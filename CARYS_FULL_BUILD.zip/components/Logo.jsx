import Image from "next/image";

export default function Logo({ className = "" }) {
  return (
    <div className={["flex items-center gap-2", className].join(" ")}>
      <Image src="/logo.png" alt="Carys" width={28} height={28} />
      <span className="font-semibold">Carys</span>
    </div>
  );
}