# Carys — Full Site

A polished Next.js (App Router) app mirroring the ChatGPT-style layout with:
- Sidebar (hamburger on mobile) with icons
- Home, Chat, Settings (ChatGPT-like), Reviews, About, Privacy, Terms
- Login/Create Account with Google, Facebook (Meta), Email via NextAuth
- Stripe Buy Button subscription page
- Tailwind styling, favicon & logo

## Quick Start

```bash
npm install
cp .env.example .env
# Fill in your provider keys and secrets
npm run dev
```

## Deploy to Vercel

1. Add environment variables from `.env` to your Vercel Project Settings.
2. Push this repo to GitHub and import into Vercel.
3. Build.

## Replace Branding

- Put your logo at `public/logo.png` (already included placeholder).
- Favicon at `public/favicon.ico` (included if provided).
- Sidebar icons in `public/icons` (replace as desired).

## Notes

- The chat box is a demo stub; integrate your model API when ready.
- If you don't set OAuth keys, login buttons will show an alert.